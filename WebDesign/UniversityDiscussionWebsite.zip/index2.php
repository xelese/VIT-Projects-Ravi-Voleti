<html>
<head>
	<title>JOIN FORUM</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--Custom CSS-->
	<link rel="stylesheet" type="text/css" href="../css/style1.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
	<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
	html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
	</style>   
</head>
<body class="w3-theme-l5">

<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="index2.php" class="w3-bar-item w3-button w3-padding-large w3-theme-d2">VIT FORUM</a>
  </div>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="My Account">
  </a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="index2.php" class="w3-bar-item w3-button w3-padding-large">VIT FORUM</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content " style="max-width:1400px;margin-top:80px">  
<img src="image_login.jpg" class = "w3-opacity-min" alt="Lights" style="width:100%">
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card w3-round w3-white">
        <div class="w3-container">
         
        </div>
      </div>
      <br>
    <!-- Alert Box -->
      <div class="w3-container w3-display-container w3-round w3-theme-l4 w3-border w3-theme-border w3-margin-bottom w3-hide-small">
        <span onclick="this.parentElement.style.display='none'" class="w3-button w3-theme-l3 w3-display-topright">
          <i class="fa fa-remove"></i>
        </span>
        <p><strong>Hey!</strong></p>
        <p>Join today by registering and get you VIT problems addressed!
			be it confessions, studies or just something that you like.
			Feel free to be a part of this wonderful community.</p>
      </div>
	<!-- End Left Column -->
    </div>
    
    <!-- Middle Column -->
    <div class="w3-col m6">
      <div class="w3-row-padding w3-display-middle" style="width:100%">
			  <h1 class ="w3-text-white w3-center" style="width:100%">WELCOME TO</h1>
			  <h2 class="w3-text-white w3-center" style="width:100%">VIT DISCUSSIONS FORUM</h2>
              <p>   </p>
      </div>
      <div class="w3-container w3-card w3-white w3-round w3-margin" ><br>
        <h4>Sign in Here</h4>
        <hr class="w3-clear">
					<div class="w3-container">
						<button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-Teal w3-center">Login</button><br><br>
							<div id="id01" class="w3-modal">
								<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">
									<div class="w3-center"><br>
										<span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-xlarge w3-hover-red w3-display-topright" title="Close Modal">&times;</span>
										<img src="avatar.png" alt="Avatar" style="width:30%" class="w3-circle w3-margin-top">
									</div>
									<form class="w3-container" method="POST" role="search" action="pages/login.php">
									<div class="w3-section">
										<input type="text" class="w3-input w3-animate-input" name="username"placeholder="Username" required><br>
										<input type="password" class="w3-input w3-animate-input" name="password"placeholder="Password" required><br>
										<button class="w3-button w3-block w3-Teal w3-padding" type="submit">Login</button>
										<input class="w3-check w3-margin-top" type="checkbox" checked="checked"> Remember me
									</div>
									</form>
									<div class="w3-container w3-border-top w3-padding-16 w3-light-grey">
										<button onclick="document.getElementById('id01').style.display='none'" type="button" class="w3-button w3-red">Cancel</button>
										<span class="w3-right w3-padding w3-hide-small">Forgot <a href="#">password?</a></span>
									</div>
								</div>
							</div>
					</div>

      </div>
      
      <div class="w3-container w3-card w3-white w3-round w3-margin""><br>
        <span class="w3-right w3-opacity"></span>
        <form method="POST" class="form-signin" action="functions/register.php">
		<h3>Don't have an account?</h3>
		<h4>Sign up Here</h4>
        <hr class="w3-clear">
		<input type="text" name="fname"placeholder="First Name"class="w3-input w3-animate-input" required><br><br>
		<input type="text" name="lname"placeholder="Last Name"class="w3-input w3-animate-input" required><br><br>
		<select class="w3-select" name="gender"required><br><br>
			<option value ="" disabled selected>Gender</option>
			<option value="Male">Male</option>
			<option value="Female">Female</option>
		</select><br><br>
		<input type="text" placeholder="Username" name="username"class="w3-input w3-animate-input" required><br><br>
		<input type="password" placeholder="Password" name="password" class="w3-input w3-animate-input" required><br><br>
		<button class="w3-button w3-teal" style="width:30%;">signup</button>
		</form>
	  </div>
    <!-- End Middle Column -->
    </div>  
  <!-- End Grid -->
  </div>
<!-- End Page Container -->
</div>
<br>

<!-- Footer -->
<footer class="w3-container w3-theme-d3 w3-padding-16">
  <a href="index.php" class="w3-bar-item w3-button w3-padding-large w3-theme-d3">ABOUT</a>
  <h5></h5>
</footer>

<script>
// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>


</body>
</html>