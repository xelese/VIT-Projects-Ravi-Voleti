<?php
$comment = " ";
include "../functions/db.php";
 					date_default_timezone_set("Asia/Kolkata");
                        $datetime=date("Y-m-d h:i:sa");		
extract($_POST);
$sql = "INSERT INTO tblpost(title,content, cat_id,datetime,user_Id) VALUES ('$title','$content','$category','$datetime','$userid')";
$res = mysqli_query($con, $sql);
$sql1 = "SELECT post_Id FROM tblpost WHERE user_Id ='$userid'";
$res1 = mysqli_query($con, $sql1);
			while($row0=mysqli_fetch_assoc($res1)){
				extract($row0);
				$postid = $post_Id;
			}
if($res==true)
                            {
                                echo '<meta http-equiv="refresh" content="0;url=questsuccess.php" />';
                            }
else
							{
								echo '<meta http-equiv="refresh" content="0;url=questfail.php" />';
							}
?>
