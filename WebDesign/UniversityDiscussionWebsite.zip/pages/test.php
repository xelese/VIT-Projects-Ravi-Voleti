<?php
include "../functions/db.php";
$my_text = "mysql";
$my_text = preg_replace('/[^\p{L}\p{N}\s]/u', '', $my_text);

$my_array  = preg_split("/ /", $my_text);

foreach ($my_array as $value){	
	if(strcasecmp($value,"is") == 0 or strcasecmp($value,"was") == 0 or strcasecmp($value,"were") == 0 or strcasecmp($value,"why") == 0 or strcasecmp($value,"when") == 0 or strcasecmp($value,"where") == 0 or strcasecmp($value,"what") == 0 or strcasecmp($value,"how") == 0 or strcasecmp($value,"who") == 0 or strcasecmp($value,"can") == 0 or strcasecmp($value,"could") == 0 or strcasecmp($value,"would") == 0 or strcasecmp($value,"will") == 0 or strcasecmp($value,"by") == 0){
		//do nothing;
		//echo "$value ";
	}
	else{
			//echo "working"; 
			$query = "SELECT answers FROM questans WHERE questions = '$value'";
			$sel = mysqli_query($con, $query);
			while($row=mysqli_fetch_assoc($sel)){
				extract($row);
				$comment = $answers;
			}
			/*$query1 = "INSERT INTO tblcomment(comment,datetime,user_Id) VALUES ('$comment','$datetime','$userid')";
			$sel1 = mysqli_query($con, $query1);
			if($sel1 == true){
				echo"bot added comment";
			}
			
			"SELECT * from tblcomment as c join tbluser as u on c.user_Id=u.user_Id where post_Id='$postid' order by datetime";
			
			
			*/
	}
}
?>