<?php
		include "db.php";
        $comment = mysqli_real_escape_string($con, $_POST['comment']);
        $userid = $_POST['userid'];
        $postid = $_POST['postid'];
        date_default_timezone_set("Asia/Kolkata");
        $datetime=date("Y-m-d h:i:sa");
        $query1 = "Insert into tblcomment (comment,post_Id,user_Id,datetime) values ('$comment','$postid','$userid','$datetime') ";
		$comment = mysqli_query($con, $query1);
        $query2 = "SELECT * from tblcomment as c join tbluser as u on c.user_Id=u.user_Id where post_Id='$postid' and c.user_Id='$userid' 
        					and c.datetime='$datetime'";
		$sql = mysqli_query($con, $query2);

		while($row=mysqli_fetch_assoc($sql)){
                    echo "<label>Comment by: </label> ".$row['fname']." ".$row['lname']."<br>";
                     echo '<label class="pull-right">'.$row['datetime'].'</label>';
                     echo "<p class='well'>".$row['comment']."</p>";
              }



              ?>