<?php
include "db.php";

extract($_POST);
	$fname = str_replace("'","`",$fname); 
	$fname = mysqli_real_escape_string($con, $fname);
	
	$lname = str_replace("'","`",$lname); 
	$lname = mysqli_real_escape_string($con, $lname); 
	        
	$username = str_replace("'","`",$username); 
	$username = mysqli_real_escape_string($con, $username); 

	$password = str_replace("'","`",$password); 
	$password = mysqli_real_escape_string($con, $password);
	$password = md5($password);

$sql1 = "SELECT * FROM tblaccount WHERE username='$username'";
$result = mysqli_query($con, $sql1);
			$test = mysqli_num_rows($result);
			
if($test==1)
{
	echo '<meta http-equiv="refresh" content="0;url=../alreadyexists.php" />';
}
else{
	
	$sql = "INSERT INTO `tbluser`(`fname`, `lname`, `gender`) VALUES ('$fname','$lname','$gender')";
	$result = mysqli_query($con, $sql);

	if($result)
		{
		
		$query1 = "SELECT * FROM `tbluser` WHERE `fname` = '$fname' ";
		$a = mysqli_query($con, $query1);
		$aa = mysqli_fetch_array($a,MYSQLI_BOTH);
		
		if($a)
		{
			$aaa = $aa['user_Id'];
			$sql = "INSERT INTO `tblaccount`(`username`, `password`, `user_Id`) VALUES('$username','$password',$aaa)";
			$res = mysqli_query($con, $sql);
			
			if($res==true)
                            {
                                echo '<meta http-equiv="refresh" content="0;url=../success.php" />';
                            }
			else
                            {
                                echo '<meta http-equiv="refresh" content="0;url=../fail.php" />';
                            }
		}
			
		
	}

}


?>