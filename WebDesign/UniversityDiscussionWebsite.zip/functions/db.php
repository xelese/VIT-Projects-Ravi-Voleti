<?php
$host = "localhost";
$user = "id5130301_xelese";
$pwd  = "v8r5a7m6";
$db   = "id5130301_dbforum";

$con = mysqli_connect($host,$user,$pwd,$db);
if($con){
	//echo "--------connection OKAY---------";
}
else{
	die("Could not connect");
	die("No database");
}

?>